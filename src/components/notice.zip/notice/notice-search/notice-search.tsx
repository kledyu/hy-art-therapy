import { useState } from 'react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import Search from '@/components/ui/search';
import { useSearchParams } from 'react-router-dom';
import { CATEGORY_LIST } from '@/constants/notice/notice-category';

const categoryList = CATEGORY_LIST;

export const NoticeSearch = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const selectedCategory = searchParams.get('category') ?? 'all';

  const getEgType = (category: string) => {
    if (category === '일반') {
      return 'GENERAL';
    }
    if (category === '실습') {
      return 'PRACTICE';
    }
    if (category === '모집') {
      return 'RECRUIT';
    }
    if (category === '전시') {
      return 'EXHIBITION';
    }

    return 'ACADEMIC';
  };

  const handleCategoryChange = async (category: string) => {
    setSearchParams((prevSearchParams) => {
      const enCategory = getEgType(category);
      console.log(prevSearchParams);

      if (category === 'all') prevSearchParams.delete('category');
      else prevSearchParams.set('category', enCategory);

      return prevSearchParams;
    });
  };

  const [searchValue, setSearchValue] = useState('');
  const handleSearch = () => {
    console.log('검색:', searchValue);
    // 여기서 검색 결과 처리 로직 추가 가능
    if (searchValue) {
      setSearchParams((prev) => {
        prev.set('keyword', searchValue);
        return prev;
      });
    } else {
      setSearchParams((prev) => {
        prev.delete('keyword');
        return prev;
      });
    }
  };

  return (
    <div className='w-full text-center'>
      {/* 구분 선택 && 검색바 */}
      <div className='flex w-full items-center gap-2 md:gap-4 mt-4 pb-[20px] md:pb-[32px]'>
        <Select
          value={selectedCategory}
          onValueChange={(value) => handleCategoryChange(value)}
        >
          <SelectTrigger className='md:px-4 md:py-2 border rounded w-[80px] md:w-[150px]'>
            <SelectValue placeholder='전체 기수' />
          </SelectTrigger>

          <SelectContent>
            <SelectItem value='all'>구분</SelectItem>
            {categoryList.map((cat) => (
              <SelectItem key={cat} value={cat}>
                {cat}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <div className='flex-1'>
          <Search
            placeholder='검색어를 입력하세요'
            searchValue={searchValue}
            setSearchValue={setSearchValue}
            onSearch={handleSearch}
          />
        </div>
      </div>
    </div>
  );
};
