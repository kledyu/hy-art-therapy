import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';

// API 타입 정의
interface NoticeFile {
  name: string;
  url: string;
}

interface NoticeData {
  title: string;
  category: string;
  content: string;
  periodStart: string;
  periodEnd: string;
  files?: NoticeFile[];
}

interface NoticeDetailResponse {
  noticeNo: number;
  title: string;
  category: string;
  content: string;
  periodStart?: string;
  periodEnd?: string;
  files?: NoticeFile[];
  createdAt: string;
  updatedAt?: string;
  viewCount: number;
  hasFile: boolean;
}

export default function NoticeEditForm() {
  const { noticeNo } = useParams<{ noticeNo: string }>();
  const navigate = useNavigate();

  const [formData, setFormData] = useState<NoticeData>({
    title: '',
    category: 'GENERAL',
    content: '',
    periodStart: '',
    periodEnd: '',
    files: [],
  });

  const [loading, setLoading] = useState(false);
  const [dataLoading, setDataLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const isEdit = !!noticeNo; // noticeNo가 있으면 수정 모드

  // 기존 공지사항 데이터 가져오기
  useEffect(() => {
    if (isEdit && noticeNo) {
      fetchNoticeData(noticeNo);
    } else {
      setDataLoading(false);
    }
  }, [isEdit, noticeNo]);

  // API에서 공지사항 데이터 가져오기
  const fetchNoticeData = async (id: string) => {
    try {
      setDataLoading(true);
      setError(null);

      // 실제 API 호출
      const response = await fetch(`/api/notices/${id}`);

      if (!response.ok) {
        throw new Error('공지사항을 불러오는데 실패했습니다.');
      }

      const data: NoticeDetailResponse = await response.json();

      // API 응답 데이터를 폼 데이터 형식으로 변환
      setFormData({
        title: data.title,
        category: data.category,
        content: data.content,
        periodStart: data.periodStart || '',
        periodEnd: data.periodEnd || '',
        files: data.files || [],
      });
    } catch (err) {
      console.error('Error fetching notice data:', err);
      setError(
        err instanceof Error ? err.message : '데이터를 불러오는데 실패했습니다.'
      );
    } finally {
      setDataLoading(false);
    }
  };

  // 폼 데이터 변경 처리
  const handleInputChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // 파일 업로드 처리
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);

    if (files.length === 0) return;

    try {
      // 파일 업로드 API 호출
      const formDataForUpload = new FormData();
      files.forEach((file) => {
        formDataForUpload.append('files', file);
      });

      const response = await fetch('/api/notices/files/upload', {
        method: 'POST',
        body: formDataForUpload,
      });

      if (!response.ok) {
        throw new Error('파일 업로드에 실패했습니다.');
      }

      const uploadedFiles: NoticeFile[] = await response.json();

      // 기존 파일 목록에 새 파일 추가
      setFormData((prev) => ({
        ...prev,
        files: [...(prev.files || []), ...uploadedFiles],
      }));
    } catch (err) {
      console.error('File upload error:', err);
      alert('파일 업로드에 실패했습니다.');
    }
  };

  // 기존 파일 삭제
  const removeFile = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      files: prev.files?.filter((_, i) => i !== index) || [],
    }));
  };

  // 폼 제출 처리
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.title.trim()) {
      alert('제목을 입력해주세요.');
      return;
    }

    if (!formData.content.trim()) {
      alert('내용을 입력해주세요.');
      return;
    }

    setLoading(true);

    try {
      const url = isEdit ? `/api/notices/${noticeNo}` : '/api/notices';
      const method = isEdit ? 'PUT' : 'POST';

      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        throw new Error(
          isEdit
            ? '공지사항 수정에 실패했습니다.'
            : '공지사항 작성에 실패했습니다.'
        );
      }

      const result = await response.json();

      alert(
        isEdit ? '공지사항이 수정되었습니다!' : '공지사항이 작성되었습니다!'
      );

      // 성공 후 상세 페이지로 이동
      navigate(`/notice/${result.noticeNo || noticeNo}`);
    } catch (err) {
      console.error('Submit error:', err);
      alert(
        err instanceof Error ? err.message : '처리 중 오류가 발생했습니다.'
      );
    } finally {
      setLoading(false);
    }
  };

  // 취소 버튼 처리
  const handleCancel = () => {
    if (isEdit) {
      navigate(`/notice/${noticeNo}`);
    } else {
      navigate('/notice');
    }
  };

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case 'GENERAL':
        return '일반';
      case 'PRACTICE':
        return '실습';
      case 'RECRUIT':
        return '모집';
      case 'EXHIBITION':
        return '전시';
      case 'ACADEMIC':
        return '학술';
      default:
        return '';
    }
  };

  // 로딩 중일 때
  if (dataLoading) {
    return (
      <div className='w-full min-h-screen bg-gray-50 py-8'>
        <div className='max-w-4xl mx-auto px-4'>
          <div className='bg-white rounded-lg shadow-md p-8'>
            <div className='text-center py-8'>
              <div className='text-lg text-gray-600'>
                데이터를 불러오는 중...
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // 에러가 발생했을 때
  if (error) {
    return (
      <div className='w-full min-h-screen bg-gray-50 py-8'>
        <div className='max-w-4xl mx-auto px-4'>
          <div className='bg-white rounded-lg shadow-md p-8'>
            <div className='text-center py-8'>
              <div className='text-lg text-red-600 mb-4'>{error}</div>
              <Button
                onClick={() => navigate('/notice')}
                className='px-6 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg'
              >
                공지사항 목록으로 돌아가기
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className='w-full min-h-screen bg-gray-50 py-8'>
      <div className='max-w-4xl mx-auto px-4'>
        <div className='bg-white rounded-lg shadow-md p-8'>
          <h1 className='text-3xl font-bold mb-8 text-gray-800'>
            {isEdit ? '공지사항 수정' : '공지사항 작성'}
          </h1>

          <form onSubmit={handleSubmit} className='space-y-6'>
            {/* 제목 */}
            <div>
              <label className='block text-sm font-semibold mb-2 text-gray-700'>
                제목 *
              </label>
              <input
                type='text'
                name='title'
                value={formData.title}
                onChange={handleInputChange}
                className='w-full p-4 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors'
                placeholder='제목을 입력하세요'
                required
              />
            </div>

            {/* 구분 */}
            <div>
              <label className='block text-sm font-semibold mb-2 text-gray-700'>
                구분 *
              </label>
              <select
                name='category'
                value={formData.category}
                onChange={handleInputChange}
                className='w-full p-4 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors bg-white'
                required
              >
                <option value='GENERAL'>일반</option>
                <option value='PRACTICE'>실습</option>
                <option value='RECRUIT'>모집</option>
                <option value='EXHIBITION'>전시</option>
                <option value='ACADEMIC'>학술</option>
              </select>
            </div>

            {/* 기간 */}
            <div className='grid grid-cols-1 md:grid-cols-2 gap-6'>
              <div>
                <label className='block text-sm font-semibold mb-2 text-gray-700'>
                  시작일
                </label>
                <input
                  type='date'
                  name='periodStart'
                  value={formData.periodStart}
                  onChange={handleInputChange}
                  className='w-full p-4 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors'
                />
              </div>
              <div>
                <label className='block text-sm font-semibold mb-2 text-gray-700'>
                  종료일
                </label>
                <input
                  type='date'
                  name='periodEnd'
                  value={formData.periodEnd}
                  onChange={handleInputChange}
                  className='w-full p-4 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors'
                />
              </div>
            </div>

            {/* 내용 */}
            <div>
              <label className='block text-sm font-semibold mb-2 text-gray-700'>
                내용 *
              </label>
              <textarea
                name='content'
                value={formData.content}
                onChange={handleInputChange}
                rows={12}
                className='w-full p-4 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors resize-vertical'
                placeholder='내용을 입력하세요'
                required
              />
            </div>

            {/* 기존 첨부파일 */}
            {formData.files && formData.files.length > 0 && (
              <div>
                <label className='block text-sm font-semibold mb-2 text-gray-700'>
                  첨부파일
                </label>
                <div className='space-y-2'>
                  {formData.files.map((file, index) => (
                    <div
                      key={index}
                      className='flex items-center justify-between p-3 bg-gray-100 rounded-lg'
                    >
                      <span className='text-blue-600 hover:text-blue-800 cursor-pointer'>
                        📎 {file.name}
                      </span>
                      <button
                        type='button'
                        onClick={() => removeFile(index)}
                        className='text-red-500 hover:text-red-700 font-medium'
                      >
                        삭제
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 새 파일 업로드 */}
            <div>
              <label className='block text-sm font-semibold mb-2 text-gray-700'>
                파일 첨부
              </label>
              <input
                type='file'
                multiple
                onChange={handleFileChange}
                className='w-full p-4 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100'
              />
            </div>

            {/* 미리보기 */}
            <div className='border-t pt-6'>
              <h3 className='text-lg font-semibold mb-4 text-gray-800'>
                미리보기
              </h3>
              <div className='bg-gray-50 p-6 rounded-lg'>
                <h2 className='text-xl font-bold mb-2'>
                  {formData.title || '제목 없음'}
                </h2>
                <div className='text-sm text-gray-600 mb-4 space-x-4'>
                  <span>구분: {getCategoryLabel(formData.category)}</span>
                  {formData.periodStart && (
                    <span>
                      기간: {formData.periodStart} ~{' '}
                      {formData.periodEnd || '종료일 없음'}
                    </span>
                  )}
                </div>
                <div className='whitespace-pre-wrap text-gray-800'>
                  {formData.content || '내용 없음'}
                </div>
                {formData.files && formData.files.length > 0 && (
                  <div className='mt-4 pt-4 border-t'>
                    <div className='text-sm font-medium text-gray-700 mb-2'>
                      첨부파일:
                    </div>
                    <div className='space-y-1'>
                      {formData.files.map((file, index) => (
                        <div key={index} className='text-sm text-blue-600'>
                          📎 {file.name}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* 버튼 */}
            <div className='flex gap-4 justify-end pt-6 border-t'>
              <Button
                type='button'
                onClick={handleCancel}
                className='px-8 py-3 bg-gray-500 hover:bg-gray-600 text-white rounded-lg font-medium transition-colors'
              >
                취소
              </Button>
              <Button
                type='submit'
                disabled={loading}
                className='px-8 py-3 bg-blue-500 hover:bg-blue-600 text-white rounded-lg font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed'
              >
                {loading ? '처리중...' : isEdit ? '수정 완료' : '작성 완료'}
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
